#pragma once

#ifdef WINAPI_XWINDOWS
bool display_is_valid();
#endif
