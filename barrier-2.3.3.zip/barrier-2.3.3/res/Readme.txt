Thank you for chosing Barrier!
https://github.com/debauchee/barrier/

Barrier allows you to share your keyboard and mouse between computers over a network.

Have fun!

Thanks,
The Barrier Team
