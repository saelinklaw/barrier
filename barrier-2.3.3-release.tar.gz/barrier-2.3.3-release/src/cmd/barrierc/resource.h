//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by barrierc.rc
//
#define IDS_FAILED                      1
#define IDS_INIT_FAILED                 2
#define IDS_UNCAUGHT_EXCEPTION          3
#define IDI_BARRIER                     101
#define IDI_TASKBAR_NOT_RUNNING         102
#define IDI_TASKBAR_NOT_WORKING         103
#define IDI_TASKBAR_NOT_CONNECTED       104
#define IDI_TASKBAR_CONNECTED           105
#define IDR_TASKBAR                     107
#define IDD_TASKBAR_STATUS              108
#define IDC_TASKBAR_STATUS_STATUS       1000
#define IDC_TASKBAR_QUIT                40001
#define IDC_TASKBAR_STATUS              40002
#define IDC_TASKBAR_LOG                 40003
#define IDC_TASKBAR_SHOW_LOG            40004
#define IDC_TASKBAR_LOG_LEVEL_ERROR     40009
#define IDC_TASKBAR_LOG_LEVEL_WARNING   40010
#define IDC_TASKBAR_LOG_LEVEL_NOTE      40011
#define IDC_TASKBAR_LOG_LEVEL_INFO      40012
#define IDC_TASKBAR_LOG_LEVEL_DEBUG     40013
#define IDC_TASKBAR_LOG_LEVEL_DEBUG1    40014
#define IDC_TASKBAR_LOG_LEVEL_DEBUG2    40015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40016
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
