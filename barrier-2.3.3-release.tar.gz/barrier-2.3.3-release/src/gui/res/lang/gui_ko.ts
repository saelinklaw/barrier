<?xml version="1.0" encoding="utf-8"?><!DOCTYPE TS><TS language="ko" sourcelanguage="en" version="2.0">
<context>
    <name>AboutDialogBase</name>
    <message>
        <location filename="res/AboutDialogBase.ui" line="38"/>
        <source>About Barrier</source>
        <translation type="finished">Barrier에 대하여</translation>
    </message>
    <message utf8="true">
        <location filename="res/AboutDialogBase.ui" line="53"/>
        <source>&lt;p&gt;
Keyboard and mouse sharing application. Cross platform and open source.&lt;br /&gt;&lt;br /&gt;
Copyright © 2012-2016 Symless Ltd.&lt;br /&gt;
Copyright © 2002-2012 Chris Schoeneman, Nick Bolton, Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Barrier is released under the GNU General Public License (GPLv2).&lt;br /&gt;&lt;br /&gt;
Barrier is based on CosmoSynergy by Richard Lee and Adam Feder.&lt;br /&gt;
The Barrier GUI is based on QSynergy by Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Visit our website for help and info (symless.com).
&lt;/p&gt;</source>
        <oldsource>&lt;p&gt;
Keyboard and mouse sharing application. Cross platform and open source.&lt;br /&gt;&lt;br /&gt;
Copyright © 2012-2016 Symless Ltd.&lt;br /&gt;
Copyright © 2002-2012 Chris Schoeneman, Nick Bolton, Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Barrier is released under the GNU General Public License (GPLv2).&lt;br /&gt;&lt;br /&gt;
Barrier is based on CosmoSynergy by Richard Lee and Adam Feder.&lt;br /&gt;
The Barrier GUI is based on QSynergy by Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Visit our website for help and info (symless.com).
&lt;/p&gt;</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/AboutDialogBase.ui" line="140"/>
        <source>Unknown</source>
        <translation type="finished">알수없음</translation>
    </message>
    <message>
        <location filename="res/AboutDialogBase.ui" line="124"/>
        <source>Version:</source>
        <translation type="finished">버전:</translation>
    </message>
    <message>
        <location filename="res/AboutDialogBase.ui" line="163"/>
        <source>&amp;Ok</source>
        <translation type="finished">확인(&amp;O)</translation>
    </message>
</context>
<context>
    <name>ActionDialogBase</name>
    <message>
        <location filename="res/ActionDialogBase.ui" line="14"/>
        <source>Configure Action</source>
        <translation type="finished">동작 설정</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="20"/>
        <source>Choose the action to perform</source>
        <translation type="finished">수행할 동작을 선택하세요</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="26"/>
        <source>Press a hotkey</source>
        <translation type="finished">단축키를 누르세요</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="36"/>
        <source>Release a hotkey</source>
        <translation type="finished">단축키를 놓으세요</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="43"/>
        <source>Press and release a hotkey</source>
        <translation type="finished">단축키를 눌렀다 놓으세요</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="69"/>
        <source>only on these screens</source>
        <translation type="finished">이 화면에서만</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="119"/>
        <source>Switch to screen</source>
        <translation type="finished">이 화면으로 전환</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="150"/>
        <source>Switch in direction</source>
        <translation type="finished">이 방향으로 전환</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="174"/>
        <source>left</source>
        <translation type="finished">왼쪽</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="179"/>
        <source>right</source>
        <translation type="finished">오른쪽</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="184"/>
        <source>up</source>
        <translation type="finished">위</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="189"/>
        <source>down</source>
        <translation type="finished">아래</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="201"/>
        <source>Lock cursor to screen</source>
        <translation type="finished">커서를 화면안에 고정</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="225"/>
        <source>toggle</source>
        <translation type="finished">토글</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="230"/>
        <source>on</source>
        <translation type="finished">켜짐</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="235"/>
        <source>off</source>
        <translation type="finished">꺼짐</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="248"/>
        <source>This action is performed when</source>
        <translation type="finished">이 동작이 수행 될 때:</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="254"/>
        <source>the hotkey is pressed</source>
        <translation type="finished">단축키가 눌렸습니다.</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="264"/>
        <source>the hotkey is released</source>
        <translation type="finished">단축키가 놓아졌습니다.</translation>
    </message>
</context>
<context>
    <name>AddClientDialog</name>
    <message>
        <location filename="res/AddClientDialogBase.ui" line="20"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/AddClientDialogBase.ui" line="35"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/AddClientDialogBase.ui" line="83"/>
        <source>Ignore auto connect clients</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HotkeyDialogBase</name>
    <message>
        <location filename="res/HotkeyDialogBase.ui" line="14"/>
        <source>Hotkey</source>
        <translation type="finished">단축키</translation>
    </message>
    <message>
        <location filename="res/HotkeyDialogBase.ui" line="20"/>
        <source>Enter the specification for the hotkey:</source>
        <translation type="finished">단축키로 설정할 키를 누르세요:</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="src/MainWindow.cpp" line="790"/>
        <source>&amp;Start</source>
        <translation type="finished">시작(&amp;S)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="237"/>
        <source>&amp;File</source>
        <translation type="finished">파일(&amp;F)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="238"/>
        <source>&amp;Edit</source>
        <translation type="finished">편집(&amp;E)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="239"/>
        <source>&amp;Window</source>
        <translation type="finished">창(&amp;W)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="240"/>
        <source>&amp;Help</source>
        <translation type="finished">도움말(&amp;H)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="364"/>
        <source>&lt;p&gt;Your version of Barrier is out of date. Version &lt;b&gt;%1&lt;/b&gt; is now available to &lt;a href=&quot;%2&quot;&gt;download&lt;/a&gt;.&lt;/p&gt;</source>
        <oldsource>&lt;p&gt;Version %1 is now available, &lt;a href=&quot;%2&quot;&gt;visit website&lt;/a&gt;.&lt;/p&gt;</oldsource>
        <translation type="finished">&lt;p&gt;사용 중인 시너지는 최신 버전이 아닙니다. 새 버전(&lt;b&gt;%1&lt;/b&gt;)을 &lt;a href=&quot;%2&quot;&gt;다운로드&lt;/a&gt; 받을 수 있습니다.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="577"/>
        <source>Program can not be started</source>
        <translation type="finished">프로그램을 시작할 수 없습니다</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="577"/>
        <source>The executable&lt;br&gt;&lt;br&gt;%1&lt;br&gt;&lt;br&gt;could not be successfully started, although it does exist. Please check if you have sufficient permissions to run this program.</source>
        <translation type="finished">실행파일&lt;br&gt;&lt;br&gt;%1&lt;br&gt;&lt;br&gt;이(가) 존재하지만 성공적으로 실행되지 못했습니다. 이 프로그램을 실행시키기 위한 충분한 권한을 가지고 있는지 확인해주세요.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="596"/>
        <source>Barrier client not found</source>
        <translation type="finished">Barrier 클라이언트를 찾을 수 없습니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="597"/>
        <source>The executable for the barrier client does not exist.</source>
        <translation type="finished">Barrier 클라이언트 실행 파일이 존재하지 않습니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="625"/>
        <source>Hostname is empty</source>
        <translation type="finished">호스트명이 비어있습니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="626"/>
        <source>Please fill in a hostname for the barrier client to connect to.</source>
        <translation type="finished">클라이언트가 접속할 호스트명을 입력해주세요.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="646"/>
        <source>Cannot write configuration file</source>
        <translation type="finished">설정파일을 쓸 수 없습니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="646"/>
        <source>The temporary configuration file required to start barrier can not be written.</source>
        <translation type="finished">Barrier를 구동하기 위해 필요한 임시 설정 파일을 작성할 수 없습니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="659"/>
        <source>Configuration filename invalid</source>
        <translation type="finished">설정 파일 이름이 올바르지 않습니다</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="660"/>
        <source>You have not filled in a valid configuration file for the barrier server. Do you want to browse for the configuration file now?</source>
        <translation type="finished">Barrier 서버를 실행하기 위한 설정 파일이 제대로 작성되어 있지 않습니다. 지금 설정 파일을 찾아 보시겠습니까?</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="688"/>
        <source>Barrier server not found</source>
        <translation type="finished">Barrier 서버를 찾을 수 없습니다</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="689"/>
        <source>The executable for the barrier server does not exist.</source>
        <translation type="finished">Barrier 서버 실행 파일이 존재하지 않습니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="764"/>
        <source>Barrier terminated with an error</source>
        <translation type="finished">Barrier가 오류로 인해 종료되었습니다</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="764"/>
        <source>Barrier terminated unexpectedly with an exit code of %1.&lt;br&gt;&lt;br&gt;Please see the log output for details.</source>
        <translation type="finished">Barrier가 %1의 코드로 비 정상적으로 종료되었습니다.&lt;br&gt;&lt;br&gt;자세한 사항은 로그 출력결과를 확인하세요</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="783"/>
        <source>&amp;Stop</source>
        <translation type="finished">중지(&amp;S)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="1038"/>
        <source>Please add the server (%1) to the grid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="1044"/>
        <source>Please drag the new client screen (%1) to the desired position on the grid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="1147"/>
        <source>Failed to detect system architecture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="1165"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="1189"/>
        <source>Failed to download Bonjour installer to location: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="1226"/>
        <source>Do you want to enable auto config and install Bonjour?

This feature helps you establish the connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="1270"/>
        <source>Auto config feature requires Bonjour.

Do you want to install Bonjour?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="815"/>
        <source>Barrier is starting.</source>
        <translation type="finished">Barrier가 실행 중 입니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="809"/>
        <source>Barrier is running.</source>
        <translation type="finished">Barrier가 실행 중 입니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="819"/>
        <source>Barrier is not running.</source>
        <translation type="finished">Barrier가 실행 중이지 않습니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="870"/>
        <source>Unknown</source>
        <translation type="finished">알수없음</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="1146"/>
        <location filename="src/MainWindow.cpp" line="1225"/>
        <location filename="src/MainWindow.cpp" line="1269"/>
        <source>Barrier</source>
        <translation type="finished">Barrier</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="987"/>
        <source>Browse for a barriers config file</source>
        <translation type="finished">barriers 설정 파일 탐색</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="408"/>
        <source>Barrier is now connected, You can close the config window. Barrier will remain connected in the background.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="434"/>
        <source>Security question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="435"/>
        <source>Do you trust this fingerprint?

%1

This is a server fingerprint. You should compare this fingerprint to the one on your server's screen. If the two don't match exactly, then it's probably not the server you're expecting (it could be a malicious user).

To automatically trust this fingerprint for future connections, click Yes. To reject this fingerprint and disconnect from the server, click No.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="1000"/>
        <source>Save configuration as...</source>
        <translation type="finished">설정을 다른 이름으로 저장...</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="1004"/>
        <source>Save failed</source>
        <translation type="finished">저장에 실패했습니다</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="1004"/>
        <source>Could not save configuration to file.</source>
        <translation type="finished">설정 사항을 파일에 저장할 수 없습니다.</translation>
    </message>
</context>
<context>
    <name>MainWindowBase</name>
    <message>
        <location filename="res/MainWindowBase.ui" line="26"/>
        <source>Barrier</source>
        <translation type="finished">Barrier</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="90"/>
        <source>Ser&amp;ver (share this computer's mouse and keyboard):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="243"/>
        <source>Screen name:</source>
        <translation type="finished">화면 이름:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="257"/>
        <source>&amp;Server IP:</source>
        <translation type="finished">서버 IP:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="380"/>
        <location filename="res/MainWindowBase.ui" line="409"/>
        <source>&amp;Start</source>
        <translation type="finished">시작(&amp;S)</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="181"/>
        <source>Use existing configuration:</source>
        <translation type="finished">기존 설정을 사용:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="190"/>
        <source>&amp;Configuration file:</source>
        <translation type="finished">설정 파일(&amp;C):</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="210"/>
        <source>&amp;Browse...</source>
        <translation type="finished">찾아 보기(&amp;B)...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="147"/>
        <source>Configure interactively:</source>
        <translation type="finished">상호작용 설정:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="159"/>
        <source>&amp;Configure Server...</source>
        <translation type="finished">서버 설정(&amp;C)</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="350"/>
        <source>Ready</source>
        <translation type="finished">준비</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="296"/>
        <source>Log</source>
        <translation type="finished">로그</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="373"/>
        <source>&amp;Reload</source>
        <translation type="finished">적용(&amp;A)</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="107"/>
        <source>IP addresses:</source>
        <translation type="finished">IP 주소:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="131"/>
        <source>Fingerprint:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="228"/>
        <source>&amp;Client (use another computer's mouse and keyboard):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="270"/>
        <source>Auto config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="390"/>
        <source>&amp;About Barrier...</source>
        <translation type="finished">Barrier에 관하여(&amp;A)...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="398"/>
        <source>&amp;Quit</source>
        <translation type="finished">종료(&amp;Q)</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="401"/>
        <source>Quit</source>
        <translation type="finished">종료</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="412"/>
        <source>Run</source>
        <translation type="finished">실행</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="423"/>
        <source>S&amp;top</source>
        <translation type="finished">중지(&amp;T)</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="426"/>
        <source>Stop</source>
        <translation type="finished">중지</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="434"/>
        <source>S&amp;how Status</source>
        <translation type="finished">상태 보기(&amp;H)</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="442"/>
        <source>&amp;Hide</source>
        <translation type="finished">숨기기</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="445"/>
        <source>Hide</source>
        <translation type="finished">숨기기</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="453"/>
        <source>&amp;Show</source>
        <translation type="finished">보이기</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="456"/>
        <source>Show</source>
        <translation type="finished">보이기</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="464"/>
        <source>Save configuration &amp;as...</source>
        <translation type="finished">설정을 다른 이름으로 저장(&amp;A)...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="467"/>
        <source>Save the interactively generated server configuration to a file.</source>
        <translation type="finished">상호작용으로 생성된 서버 설정을 파일로 저장하기.</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="475"/>
        <source>Settings</source>
        <translation type="finished">설정</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="478"/>
        <source>Edit settings</source>
        <translation type="finished">설정 편집</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="486"/>
        <source>Run Wizard</source>
        <translation type="finished">마법사 실행</translation>
    </message>
</context>
<context>
    <name>NewScreenWidget</name>
    <message>
        <location filename="src/NewScreenWidget.cpp" line="32"/>
        <source>Unnamed</source>
        <translation type="finished">이름없음</translation>
    </message>
</context>
<context>
    <name>PluginManager</name>
    <message>
        <location filename="src/PluginManager.cpp" line="58"/>
        <source>Failed to get plugin directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/PluginManager.cpp" line="63"/>
        <source>Failed to get profile directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/PluginManager.cpp" line="136"/>
        <source>Failed to download plugin '%1' to: %2
%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/PluginManager.cpp" line="167"/>
        <source>Could not get Windows architecture type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/PluginManager.cpp" line="191"/>
        <source>Could not get Linux architecture type.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PluginWizardPage</name>
    <message>
        <location filename="res/PluginWizardPageBase.ui" line="14"/>
        <source>Setup Barrier</source>
        <translation type="finished">시너지 설정</translation>
    </message>
    <message>
        <location filename="res/PluginWizardPageBase.ui" line="101"/>
        <source>Please wait...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/PluginWizardPage.cpp" line="72"/>
        <source>Error: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/PluginWizardPage.cpp" line="80"/>
        <location filename="src/PluginWizardPage.cpp" line="201"/>
        <source>Setup complete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/PluginWizardPage.cpp" line="93"/>
        <source>Downloading '%1' plugin (%2/%3)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/PluginWizardPage.cpp" line="104"/>
        <source>Plugins installed successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/PluginWizardPage.cpp" line="120"/>
        <source>Generating SSL certificate...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/PluginWizardPage.cpp" line="170"/>
        <source>Downloading plugin: %1 (1/%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/PluginWizardPage.cpp" line="239"/>
        <source>Getting plugin list...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="src/MainWindow.cpp" line="60"/>
        <source>Barrier Configurations (*.sgc);;All files (*.*)</source>
        <translation type="finished">Barrier 설정파일 (*.sgc);;모든 파일 (*.*)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="67"/>
        <source>Barrier Configurations (*.conf);;All files (*.*)</source>
        <translation type="finished">Barrier 설정파일 (*.conf);;모든 파일 (*.*)</translation>
    </message>
    <message>
        <location filename="src/main.cpp" line="119"/>
        <source>System tray is unavailable, quitting.</source>
        <translation type="finished">시스템 트레이를 사용할 수 없어 종료합니다.</translation>
    </message>
</context>
<context>
    <name>ScreenSettingsDialog</name>
    <message>
        <location filename="src/ScreenSettingsDialog.cpp" line="67"/>
        <source>Screen name is empty</source>
        <translation type="finished">스크린 이름이 비었습니다</translation>
    </message>
    <message>
        <location filename="src/ScreenSettingsDialog.cpp" line="68"/>
        <source>The screen name cannot be empty. Please either fill in a name or cancel the dialog.</source>
        <translation type="finished">스크린 명은 비워둘 수 없습니다. 이름을 입력하거나 대화창을 취소하세요.</translation>
    </message>
    <message>
        <location filename="src/ScreenSettingsDialog.cpp" line="83"/>
        <source>Screen name matches alias</source>
        <translation type="finished">별명과 일치하는 화면 이름</translation>
    </message>
    <message>
        <location filename="src/ScreenSettingsDialog.cpp" line="84"/>
        <source>The screen name cannot be the same as an alias. Please either remove the alias or change the screen name.</source>
        <translation type="finished">화면 이름은 별명과 동일할 수 없습니다. 별명을 제거하거나 화면 이름을 바꿔주세요.</translation>
    </message>
</context>
<context>
    <name>ScreenSettingsDialogBase</name>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="14"/>
        <source>Screen Settings</source>
        <translation type="finished">화면 설정</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="22"/>
        <source>Screen &amp;name:</source>
        <translation type="finished">화면 이름(&amp;N):</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="42"/>
        <source>A&amp;liases</source>
        <translation type="finished">별칭(&amp;L)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="57"/>
        <source>&amp;Add</source>
        <translation type="finished">추가(&amp;A)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="74"/>
        <source>&amp;Remove</source>
        <translation type="finished">삭제(&amp;R)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="97"/>
        <source>&amp;Modifier keys</source>
        <translation type="finished">보조 키(&amp;M)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="106"/>
        <source>&amp;Shift:</source>
        <translation type="finished">&amp;Shift:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="117"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="164"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="211"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="258"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="305"/>
        <source>Shift</source>
        <translation type="finished">Shift</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="122"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="169"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="216"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="263"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="310"/>
        <source>Ctrl</source>
        <translation type="finished">Ctrl</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="127"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="174"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="221"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="268"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="315"/>
        <source>Alt</source>
        <translation type="finished">Alt</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="132"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="179"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="226"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="273"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="320"/>
        <source>Meta</source>
        <translation type="finished">메타</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="137"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="184"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="231"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="278"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="325"/>
        <source>Super</source>
        <translation type="finished">슈퍼</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="142"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="189"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="236"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="283"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="330"/>
        <source>None</source>
        <translation type="finished">없음</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="150"/>
        <source>&amp;Ctrl:</source>
        <translation type="finished">&amp;Ctrl:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="197"/>
        <source>Al&amp;t:</source>
        <translation type="finished">Al&amp;t:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="244"/>
        <source>M&amp;eta:</source>
        <translation type="finished">메타(&amp;M):</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="291"/>
        <source>S&amp;uper:</source>
        <translation type="finished">슈퍼(&amp;U):</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="358"/>
        <source>&amp;Dead corners</source>
        <translation type="finished">사용하지 않는 모서리(&amp;D)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="367"/>
        <source>Top-left</source>
        <translation type="finished">상단 왼쪽</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="374"/>
        <source>Top-right</source>
        <translation type="finished">상단 오른쪽</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="381"/>
        <source>Bottom-left</source>
        <translation type="finished">하단 왼쪽</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="388"/>
        <source>Bottom-right</source>
        <translation type="finished">하단 오른쪽</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="397"/>
        <source>Corner Si&amp;ze:</source>
        <translation type="finished">모서리 크기(&amp;Z)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="428"/>
        <source>&amp;Fixes</source>
        <translation type="finished">고정(&amp;F)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="437"/>
        <source>Fix CAPS LOCK key</source>
        <translation type="finished">CAPS LOCK 키 고정</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="444"/>
        <source>Fix NUM LOCK key</source>
        <translation type="finished">NUM LOCK 키 고정</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="451"/>
        <source>Fix SCROLL LOCK key</source>
        <translation type="finished">SCROLL LOCK 키 고정</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="458"/>
        <source>Fix XTest for Xinerama</source>
        <translation type="finished">Xinerama를 위한 XTest 고정</translation>
    </message>
</context>
<context>
    <name>ScreenSetupModel</name>
    <message>
        <location filename="src/ScreenSetupModel.cpp" line="51"/>
        <source>&lt;center&gt;Screen: &lt;b&gt;%1&lt;/b&gt;&lt;/center&gt;&lt;br&gt;Double click to edit settings&lt;br&gt;Drag screen to the trashcan to remove it</source>
        <translation type="finished">&lt;center&gt;화면: &lt;b&gt;%1&lt;/b&gt;&lt;/center&gt;&lt;br&gt;설정을 편집하려면 더블클릭&lt;br&gt;삭제하려면 휴지통으로 드래그 하세요</translation>
    </message>
</context>
<context>
    <name>ServerConfigDialog</name>
    <message>
        <location filename="src/ServerConfigDialog.cpp" line="75"/>
        <source>Configure server</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ServerConfigDialogBase</name>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="14"/>
        <source>Server Configuration</source>
        <translation type="finished">서버 설정</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="24"/>
        <source>Screens and links</source>
        <translation type="finished">화면과 링크</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="35"/>
        <source>Drag a screen from the grid to the trashcan to remove it.</source>
        <translation type="finished">삭제하려면 화면을 휴지통으로 드래그 하세요.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="60"/>
        <source>Configure the layout of your barrier server configuration.</source>
        <translation type="finished">Barrier 서버 구성과 레이아웃을 설정하세요.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="73"/>
        <source>Drag this button to the grid to add a new screen.</source>
        <translation type="finished">새로운 화면을 추가하려면 이 버튼을 격자 안으로 드래그 하세요.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="128"/>
        <source>Drag new screens to the grid or move existing ones around.
Drag a screen to the trashcan to delete it.
Double click on a screen to edit its settings.</source>
        <translation type="finished">새로운 화면을 추가하려면 상단의 화면을 격자 안으로 드래그 하세요.
화면을 삭제하려면 휴지통으로 드래그 하세요.
화면 설정을 편집하려면 더블클릭 하세요.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="157"/>
        <source>Hotkeys</source>
        <translation type="finished">단축키</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="163"/>
        <source>&amp;Hotkeys</source>
        <translation type="finished">단축키(&amp;H)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="175"/>
        <source>&amp;New</source>
        <translation type="finished">생성(&amp;N)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="185"/>
        <source>&amp;Edit</source>
        <translation type="finished">편집(&amp;E)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="195"/>
        <source>&amp;Remove</source>
        <translation type="finished">삭제(&amp;R)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="218"/>
        <source>A&amp;ctions</source>
        <translation type="finished">행동(&amp;C)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="230"/>
        <source>Ne&amp;w</source>
        <translation type="finished">생성(&amp;W)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="240"/>
        <source>E&amp;dit</source>
        <translation type="finished">편집(&amp;D)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="250"/>
        <source>Re&amp;move</source>
        <translation type="finished">삭제(&amp;M)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="274"/>
        <source>Advanced server settings</source>
        <translation type="finished">고급 설정</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="280"/>
        <source>&amp;Switch</source>
        <translation type="finished">전환(&amp;S)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="291"/>
        <source>Switch &amp;after waiting</source>
        <translation type="finished">대기 후 전환(&amp;A)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="330"/>
        <location filename="res/ServerConfigDialogBase.ui" line="383"/>
        <location filename="res/ServerConfigDialogBase.ui" line="458"/>
        <source>ms</source>
        <translation type="finished">ms</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="344"/>
        <source>Switch on double &amp;tap within</source>
        <translation type="finished">지정시간 안에 더블 탭으로 전환(&amp;T)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="408"/>
        <source>&amp;Options</source>
        <translation type="finished">옵션(&amp;O)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="419"/>
        <source>&amp;Check clients every</source>
        <translation type="finished">지정 시간마다 클라이언트 확인(&amp;C)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="470"/>
        <source>Use &amp;relative mouse moves</source>
        <translation type="finished">상대적인 마우스 이동 사용(&amp;R)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="480"/>
        <source>S&amp;ynchronize screen savers</source>
        <translation type="finished">스크린세이버 동기화(&amp;Y)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="490"/>
        <source>Don't take &amp;foreground window on Windows servers</source>
        <translation type="finished">클라이언트로 전환시해도 서버의 포커스 방지 (전체화면 작업중 클라이언트로 전환해도 전체화면이 유지되며, 서버에서 전체화면 중 최소화 후 클라이언트 전환시 전체화면을 방지)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="510"/>
        <source>Ignore auto config clients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="520"/>
        <source>&amp;Dead corners</source>
        <translation type="finished">사용하지 않는 모서리(&amp;D)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="529"/>
        <source>To&amp;p-left</source>
        <translation type="finished">상단 왼쪽(&amp;P)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="536"/>
        <source>Top-rig&amp;ht</source>
        <translation type="finished">상단 오른쪽(&amp;H)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="543"/>
        <source>&amp;Bottom-left</source>
        <translation type="finished">하단 왼쪽(&amp;B)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="550"/>
        <source>Bottom-ri&amp;ght</source>
        <translation type="finished">하단 오른쪽(&amp;G)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="572"/>
        <source>Cor&amp;ner Size:</source>
        <translation type="finished">모서리 크기(&amp;N):</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="src/SettingsDialog.cpp" line="131"/>
        <source>Save log file to...</source>
        <translation type="finished">로그 파일 저장하기...</translation>
    </message>
    <message>
        <location filename="src/SettingsDialog.cpp" line="151"/>
        <source>Elevate Barrier</source>
        <translation type="finished">Barrier 승급</translation>
    </message>
    <message>
        <location filename="src/SettingsDialog.cpp" line="152"/>
        <source>Are you sure you want to elevate Barrier?

This allows Barrier to interact with elevated processes and the UAC dialog, but can cause problems with non-elevated processes. Elevate Barrier only if you really need to.</source>
        <translation type="finished">Barrier의 권한을 승급 하시겠습니까?
이것을 허용하게 되면 Barrier와 승급된 프로세스, UAC 대화상자와 상호작용 할 수 있지만, 승급되지 않은 프로세스들과 문제가 생길 수 있습니다. Barrier 권한 승급은 반드시 필요한 경우에만 사용하세요.</translation>
    </message>
</context>
<context>
    <name>SettingsDialogBase</name>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="14"/>
        <source>Settings</source>
        <translation type="finished">설정</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="32"/>
        <source>Sc&amp;reen name:</source>
        <translation type="finished">화면 이름(&amp;R):</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="49"/>
        <source>P&amp;ort:</source>
        <translation type="finished">포트(&amp;O):</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="78"/>
        <source>&amp;Interface:</source>
        <translation type="finished">인터페이스(&amp;I):</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="120"/>
        <source>Elevate mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="127"/>
        <source>&amp;Hide on startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="146"/>
        <source>&amp;Network Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="155"/>
        <source>Use &amp;SSL encryption (unique certificate)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="184"/>
        <source>Logging</source>
        <translation type="finished">로그 기록</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="202"/>
        <source>&amp;Logging level:</source>
        <translation type="finished">기록 수준(&amp;L):</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="251"/>
        <source>Log to file:</source>
        <translation type="finished">파일로 저장:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="268"/>
        <source>Browse...</source>
        <translation type="finished">찾아보기...</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="213"/>
        <source>Error</source>
        <translation type="finished">오류</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="107"/>
        <source>&amp;Language:</source>
        <translation type="finished">언어:(&amp;l)</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="20"/>
        <source>&amp;Miscellaneous</source>
        <translation type="finished">기타</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="218"/>
        <source>Warning</source>
        <translation type="finished">경고</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="223"/>
        <source>Note</source>
        <translation type="finished">알림</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="228"/>
        <source>Info</source>
        <translation type="finished">정보</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="233"/>
        <source>Debug</source>
        <translation type="finished">디버그</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="238"/>
        <source>Debug1</source>
        <translation type="finished">디버그1</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="243"/>
        <source>Debug2</source>
        <translation type="finished">디버그2</translation>
    </message>
</context>
<context>
    <name>SetupWizard</name>
    <message>
        <location filename="src/SetupWizard.cpp" line="72"/>
        <source>Setup Barrier</source>
        <translation type="finished">시너지 설정</translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="113"/>
        <source>Please select an option.</source>
        <translation type="finished">옵션을 선택하세요.</translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="80"/>
        <source>Please enter your email address and password.</source>
        <translation type="finished">이메일 주소 및 암호를 입력하세요.</translation>
    </message>
</context>
<context>
    <name>SetupWizardBase</name>
    <message>
        <location filename="res/SetupWizardBase.ui" line="26"/>
        <source>Setup Barrier</source>
        <translation type="finished">시너지 설정</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="30"/>
        <source>Welcome</source>
        <translation type="finished">환영합니다.</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="39"/>
        <source>Thanks for installing Barrier!</source>
        <translation type="finished">시너지를 설치하여 주셔서 감사합니다.</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="114"/>
        <source>Barrier lets you easily share your mouse and keyboard between multiple computers on your desk, and it's Free and Open Source. Just move your mouse off the edge of one computer's screen on to another. You can even share all of your clipboards. All you need is a network connection. Barrier is cross-platform (works on Windows, Mac OS X and Linux).</source>
        <translation type="finished">Barrier는 마우스와 키보드를  여러 컴퓨터에 쉽게 공유하여 사용할 수 있게 해주는 무료 오픈 소스 프로그램입니다. 마우스를 한쪽 컴퓨터의 화면 끝으로 옮기기만 하면 다른 컴퓨터의 화면으로 이동할 수 있으며 클립보드의 내용까지도 공유할 수 있습니다. 필요한 것은 단지 네트워크 연결 뿐이며 Barrier는 여러 플랫폼(Windows와 Mac OS X, Linux)에서 사용할 수 있습니다. </translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="125"/>
        <source>Activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="131"/>
        <source>&amp;Activate now...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="152"/>
        <source>Email:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="178"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="204"/>
        <source>&lt;a href=&quot;https://symless.com/account/reset/&quot;&gt;Forgot password&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="232"/>
        <source>&amp;Skip activation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="277"/>
        <source>&amp;Server (share this computer's mouse and keyboard)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="290"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;My main mouse and keyboard are connected to this computer. This will allow you to move your mouse over to another computer's screen. There can only be one server in your setup.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="326"/>
        <source>&amp;Client (use another computer's mouse and keyboard)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="339"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;You have already set up a server. This computer will be controlled using the server's mouse and keyboard. There can be many clients in your setup.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="262"/>
        <source>Server or Client?</source>
        <translation type="finished">서버 또는 클라이언트?</translation>
    </message>
</context>
<context>
    <name>SslCertificate</name>
    <message>
        <location filename="src/SslCertificate.cpp" line="42"/>
        <source>Failed to get profile directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/SslCertificate.cpp" line="141"/>
        <source>SSL certificate generated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/SslCertificate.cpp" line="170"/>
        <source>SSL fingerprint generated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/SslCertificate.cpp" line="173"/>
        <source>Failed to find SSL fingerprint.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VersionChecker</name>
    <message>
        <location filename="src/VersionChecker.cpp" line="102"/>
        <source>Unknown</source>
        <translation type="finished">알수없음</translation>
    </message>
</context>
<context>
    <name>WebClient</name>
    <message>
        <location filename="src/WebClient.cpp" line="44"/>
        <source>An error occurred while trying to sign in. Please contact the helpdesk, and provide the following details.

%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/WebClient.cpp" line="65"/>
        <source>Login failed, invalid email or password.</source>
        <translation type="finished">로그인에 실패했습니다. 전자메일 또는 암호가 잘못되었습니다.</translation>
    </message>
    <message>
        <location filename="src/WebClient.cpp" line="78"/>
        <source>Login failed, an error occurred.

%1</source>
        <translation type="finished">로그인에 실패했습니다. 오류가 발생했습니다.
%1</translation>
    </message>
    <message>
        <location filename="src/WebClient.cpp" line="86"/>
        <source>Login failed, an error occurred.

Server response:

%1</source>
        <translation type="finished">로그인에 실패했습니다. 오류가 발생했습니다.
서버 응답은 다음과 같습니다:
%1</translation>
    </message>
    <message>
        <location filename="src/WebClient.cpp" line="101"/>
        <source>An error occurred while trying to query the plugin list. Please contact the help desk, and provide the following details.

%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/WebClient.cpp" line="120"/>
        <source>Get plugin list failed, invalid user email or password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/WebClient.cpp" line="131"/>
        <source>Get plugin list failed, an error occurred.

%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/WebClient.cpp" line="137"/>
        <source>Get plugin list failed, an error occurred.

Server response:

%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ZeroconfService</name>
    <message>
        <location filename="src/ZeroconfService.cpp" line="82"/>
        <source>zeroconf server detected: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ZeroconfService.cpp" line="91"/>
        <source>zeroconf client detected: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ZeroconfService.cpp" line="99"/>
        <location filename="src/ZeroconfService.cpp" line="130"/>
        <source>Zero configuration service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ZeroconfService.cpp" line="100"/>
        <source>Error code: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ZeroconfService.cpp" line="131"/>
        <source>Unable to start the zeroconf: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ZeroconfService.cpp" line="140"/>
        <source>Barrier</source>
        <translation type="finished">Barrier</translation>
    </message>
    <message>
        <location filename="src/ZeroconfService.cpp" line="141"/>
        <source>Failed to get local IP address. Please manually type in server address on your clients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ZeroconfService.cpp" line="147"/>
        <location filename="src/ZeroconfService.cpp" line="154"/>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>